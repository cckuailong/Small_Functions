package com.lovebear.baiduMap;

import java.io.BufferedReader;  
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;  
import java.io.InputStreamReader;  
import java.io.UnsupportedEncodingException;  
import java.net.MalformedURLException;  
import java.net.URL;  
import java.net.URLConnection;  
import java.util.HashMap;  
import java.util.Map;  
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
  
/**  
* ��ȡ��γ�� 
*  
* ���ظ�ʽ��Map<String,Object> map map.put("status",  
* reader.nextString());//״̬ map.put("result", list);//��ѯ���  
* list<map<String,String>>  
* ��Կ:EESYANH7xEOT8bQUpwxjZlWRaslaGqd1  
*/   
public class baiduMap {  
  
  
    public static void main(String[] args) throws IOException {  
        
    	baiduMap getLatAndLngByBaidu = new baiduMap();  
        /* 
        Map<String,Double> map=getLatAndLngByBaidu.getLngAndLat("��������ɽ����");  
        System.out.println("���ȣ�"+map.get("lng")+"---γ�ȣ�"+map.get("lat"));  
        */
    	//getLatAndLngByBaidu.handleData();
    	getLatAndLngByBaidu.getMap(getLatAndLngByBaidu);
    }  
    
    public void handleData(){
    	try {
            // read file content from file
            StringBuffer sb= new StringBuffer("");
           
            FileReader reader = new FileReader("C:/Users/lovebear96/Desktop/1.txt");
            BufferedReader br = new BufferedReader(reader);
           
            String str = null;
            int flag=0;
            while((str = br.readLine()) != null) {
            	
                  if(str.trim().equals("??")){
                	  flag=1;
                  }else if(flag==1){
                	  String tmp=str.trim();
                	  if(tmp.endsWith("\"")){
                		  tmp=tmp.substring(0,tmp.length()-1);
                	  }
                	  sb.append(tmp+"\n");
                	  flag=0;
                  }else{
                	  flag=0;
                  }
                  
            }
           
            br.close();
            reader.close();
           
            // write string to file
            FileWriter writer = new FileWriter("C:/Users/lovebear96/Desktop/2.txt");
            BufferedWriter bw = new BufferedWriter(writer);
            bw.write(sb.toString());
           
            bw.close();
            writer.close();
      }
      catch(FileNotFoundException e) {
                  e.printStackTrace();
            }
            catch(IOException e) {
                  e.printStackTrace();
            }
      }

    public void getMap(baiduMap getLatAndLngByBaidu){
    	
    	try {
    		Map<String,Double> map=null;
            // read file content from file
            StringBuffer sb= new StringBuffer("");
           
            FileReader reader = new FileReader("C:/Users/lovebear96/Desktop/2.txt");
            BufferedReader br = new BufferedReader(reader);
           
            String str = null;
            int flag=0;
            while((str = br.readLine()) != null) {
            	map=getLatAndLngByBaidu.getLngAndLat(str.trim()); 
                if(map==null)
                	continue;
                else {
                	//System.out.println("���ȣ�"+map.get("lng")+"---γ�ȣ�"+map.get("lat"));
                	sb.append(str.trim()+" "+map.get("lng")+" "+map.get("lat")+"\n");
				}
            }
           
            br.close();
            reader.close();
           
            // write string to file
            FileWriter writer = new FileWriter("C:/Users/lovebear96/Desktop/3.txt");
            BufferedWriter bw = new BufferedWriter(writer);
            bw.write(sb.toString());
            System.out.println("finish");
            bw.close();
            writer.close();
      }
      catch(FileNotFoundException e) {
                  e.printStackTrace();
            }
            catch(IOException e) {
                  e.printStackTrace();
            }
    }
      
    public static Map<String,Double> getLngAndLat(String address){  
        Map<String,Double> map=new HashMap<String, Double>();  
         String url = "http://api.map.baidu.com/geocoder/v2/?address="+address+"&output=json&ak=EESYANH7xEOT8bQUpwxjZlWRaslaGqd1";  
        
         String json = loadJSON(url); 
         if(json==null){
        	 return null;
         }
         try{ 
            JSONObject obj = JSON.parseObject(json);  
         
            if(obj.get("status").toString().equals("0")){  
                double lng=obj.getJSONObject("result").getJSONObject("location").getDouble("lng");  
                double lat=obj.getJSONObject("result").getJSONObject("location").getDouble("lat");  
                map.put("lng", lng);  
                map.put("lat", lat);  
                //System.out.println("���ȣ�"+lng+"---γ�ȣ�"+lat);  
            }else{  
                //System.out.println("δ�ҵ���ƥ��ľ�γ�ȣ�");  
            }  
        return map;  
         }catch(Exception e){
        	 return null;
         }
    }  
      
     public static String loadJSON (String url) {  
            StringBuilder json = new StringBuilder();  
            try {  
                URL oracle = new URL(url);  
                URLConnection yc = oracle.openConnection();  
                BufferedReader in = new BufferedReader(new InputStreamReader(  
                                            yc.getInputStream()));  
                String inputLine = null;  
                while ( (inputLine = in.readLine()) != null) {  
                    json.append(inputLine);  
                }  
                in.close();  
            } catch (MalformedURLException e) {  
            	return null;
            } catch (IOException e) {  
            	return null;
            }  
            return json.toString();  
        }  
       
       
}  
