f=open('C:/Users/lovebear96/Desktop/hackit/data/ayname/ayname_data/aymail.txt','r')
res=f.read().replace("', '",'\n')[2:-2]
f.close()
f1=open('C:/Users/lovebear96/Desktop/hackit/data/ayname/ayname_data/managed_mail.txt','w')
f1.write(res)
f1.close()