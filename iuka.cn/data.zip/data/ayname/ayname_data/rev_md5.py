import requests
import time

f=open('C:/Users/lovebear96/Desktop/hackit/data/ayname/ayname_data/ayanquan.txt','r')
res=f.read().split("\n")[:-1]
f.close()

url='http://www.nitrxgen.net/md5db/'
f1=open('C:/Users/lovebear96/Desktop/hackit/data/ayname/ayname_data/ayanquan_m.txt','w')

i=1
for hash in res:
	r=requests.get(url+hash,timeout=4)
	if r.text=='null':
		f1.write('null\n')
	else:
		f1.write(r.text+'\n')
	time.sleep(0.5)
	print i
	i=i+1

f1.close()